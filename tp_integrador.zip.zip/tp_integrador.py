# Ejercicio 1— “Caja del Kiosco”
# Objetivo: Simular una compra con validaciones y cálculo de total.

print("=" * 30)
print(" " * 6, "CAJA DE KIOSCO")
print("=" * 30)
print()

# 1. Pedir nombre del cliente (solo letras, validar con .isalpha() en while).

cliente = input("Cliente: ")
while not cliente.isalpha():

    print("Error: Debe contener solo letras")
    cliente = input("Cliente: ")

    if cliente == "":
        print("Error: No puede haber un dato vacio")
        cliente = input("Cliente: ")

# 2. Pedir cantidad de productos a comprar (número entero positivo, validar con
# .isdigit() en while).

print()
productos = input("Cantidad de productos a comprar: ")

while not productos.isdigit() or int(productos) <= 0:

    if not productos.isdigit():
        print("Error: Debes ingresar un valor numerico")
    else:
        print("Error: No se puede ingresar valores negativos ni cero (0)")

    productos = input("Cantidad de productos a comprar: ")

productos = int(productos)

# 3. Por cada producto (usar for):
# Pedir precio (entero, validar .isdigit()).

total = 0
total_descuento = 0
producto_x = ""

print()
for i in range(1, productos + 1):

    precio = input(f"Producto {i} - Precio: ")

    while not precio.isdigit():
        print("Error: Debes ingresar un dato numerico")
        precio = input(f"Producto {i} - Precio: ")

    precio = int(precio)
    total += precio
    
# Pedir si tiene descuento S/N (validar con while, aceptar s o n en
# cualquier mayuscula/minuscula).

    descuento = input("Descuento (S/N): ").lower()

    while descuento != "s" and descuento != "n":
            print("Error: Debes ingresar S o N")
            descuento = input("Descuento (S/N): ").lower()

# Si tiene descuento: aplicar 10% al precio de ese producto.

    if descuento == "s":
        aplicar_descuento = precio * 0.10
        total_descuento += aplicar_descuento

    producto_x += f"Producto: {i} - Precio: {precio} - Descuento (S/N): {descuento}\n"

# 4. Al final mostrar:
# Total sin descuentos
# Total con descuentos
# Ahorro total
# Promedio por producto (usar float y formatear con :.2f, ejem:

print("_" * 30)
print(" " * 6, "RESULTADO FINAL")
print("_" * 30)

print()
print(f"Cliente: {cliente}")
print(f"Cantidad de productos: {productos}")

print()

print(f"{producto_x}")

print()

print(f"Total sin descuento: ${total}")

total_a_pagar = total - total_descuento
print(f"Total con descuento: ${total_a_pagar}")

ahorro = total_descuento
print(f"Ahorro: ${ahorro}")

promedio_por_producto = total_a_pagar / productos
print(f"Promedio por producto: ${promedio_por_producto:.2f}")
print()
print("_" * 30)

print()

#===========================================================================================================

#Ejercicio 2 — “Acceso al Campus y Menú Seguro”

print("=" * 30)
print("Acceso al Campus y Menu Seguro")
print("=" * 30)
print()

#1. Definir credenciales fijas en el código:

usuario_correcto = "alumno"
clave_correcta = "python123"

#2. Permitir máximo 3 intentos para ingresar usuario y clave.

intentos = 0
acceso = False

while intentos < 3:

    intentos += 1

    print(f"Intento {intentos}/3:")
    usuario = input("Usuario: ")
    clave = input("Clave: ")
        

    if usuario == usuario_correcto and clave == clave_correcta:
        print("Acceso condedido")
        acceso = True
        break

    else:
        print("Error: credenciales invalidas")

# Si falla 3 veces: mostrar “Cuenta bloqueada” y terminar.

if not acceso:

    print("Cuenta bloqueada")
    print()

# Si ingresa bien: mostrar un menú repetitivo (usar while) hasta elegir salir:

if acceso:

    while True:

        print()
        print("=" * 20)
        print("MENU DE OPCIONES")
        print("1. Ver estado de inscripcion")
        print("2. Cambiar clave")
        print("3. Mostrar mensaje motivacional")
        print("4. Salir")
        print("=" * 20)
        print()
        opcion = input("Seleccione una opcion: ")

# 5. Validación del menú:
# Debe ser número (.isdigit())
# Debe estar entre 1 y 4

        while not opcion.isdigit():

            print("Error: ingrese un numero valido")
            opcion = input("Seleccione una opcion: ")

        opcion = int(opcion)

        if opcion < 1 or opcion > 4:
            print("Error: fuera del rango")

# 1. Ver estado de inscripción (mostrar “Inscripto”)

        elif opcion == 1:

            print("Inscripto")

# 2. Cambiar clave (pedir nueva clave y confirmación; deben coincidir)

        elif opcion == 2:

# Cambio de clave
# La nueva clave debe tener mínimo 6 caracteres (validar con len()), si no, rechazar.

            nueva_clave = input("Nueva clave: ")

            if len(nueva_clave) < 6:
                print("Error: debe contener mas de 6 digitos")

            else:
                confirmar_clave = input("Confirmar nueva clave: ")

                if nueva_clave == confirmar_clave:
                    print("Clave actualizada correctamente")

                else:
                    print("Error: las claves no coinciden")

# 3. Mostrar mensaje motivacional (1 frase)

        elif opcion == 3:

            print("Nunca tengas miedo a equivacarte, el exito exige a uno a equivocarse!")

# 4. Salir

        elif opcion == 4:

            print("Saliendo del menu...")
            print()

            break

print()

#===========================================================================================================

# Ejercicio 3 — “Agenda de Turnos con Nombres (sin listas)”

print("=" * 20)
print(" " * 1, "AGENDA DE TURNOS")
print("=" * 20)

# Hay 2 días de atención: Lunes y Martes.

# • Lunes: 4 turnos
lunes1 = ""
lunes2 = ""
lunes3 = ""
lunes4 = ""

# • Martes: 3 turnos
martes1 = ""
martes2 = ""
martes3 = ""

# 1. Pedir nombre del operador (solo letras).

nombre_operador = input("Nombre operador: ")

while not nombre_operador.isalpha():
    print("Error: Debe ingresar letras en su nombre")
    nombre_operador = input("Nombre operador: ")

opcion = ""
while opcion != "5":

    # Menú repetitivo hasta salir:
    print()
    print("=================")
    print("MENU DE OPCIONES")
    print("=================")
    opcion = input("""
1. Reservar turno
2. Cancelar turno (por nombre)
3. Ver agenda del dia
4. Ver resumen general
5. Cerrar sistema

Seleccione una opcion: """)

    while not opcion.isdigit() or opcion not in ("1", "2", "3", "4", "5"):
        print("Error: opcion invalida")
        opcion = input("Seleccione una opcion: ")

    # Reservar:
    if opcion == "1":

        # Elegir día (1=Lunes, 2=Martes).

        elegir_dia = input("Eliga el dia del turno (1 = LUNES / 2 = MARTES): ")
        while not elegir_dia.isdigit() or elegir_dia not in ("1", "2"):
            print("Error: debe elegir entre opcion 1 o 2")
            elegir_dia = input("Eliga el dia del turno (1 = LUNES / 2 = MARTES): ")

        # Pedir nombre del paciente (solo letras).

        paciente = input("Nombre del paciente: ")
        while not paciente.isalpha():
            print("Error: el nombre debe contener letras")
            paciente = input("Nombre del paciente: ")

        # Verificar que no esté repetido en ese día (comparando con las variables ya cargadas).

        if elegir_dia == "1":

            if (paciente == lunes1 or
                paciente == lunes2 or
                paciente == lunes3 or
                paciente == lunes4):

                print("Error: el paciente ya tiene un turno reservado para el Lunes")

            # Guardar en el primer espacio libre (ej. lunes1, lunes2…).

            elif lunes1 == "":
                lunes1 = paciente
                print("Turno reservado. Lunes - Turno 1")

            elif lunes2 == "":
                lunes2 = paciente
                print("Turno reservado. Lunes - Turno 2")

            elif lunes3 == "":
                lunes3 = paciente
                print("Turno reservado. Lunes - Turno 3")

            elif lunes4 == "":
                lunes4 = paciente
                print("Turno reservado. Lunes - Turno 4")

            else:
                print("No hay turnos disponibles para Lunes")

        else:

            if (paciente == martes1 or
            paciente == martes2 or
                paciente == martes3):

                print("Error: el paciente ya tiene un turno reservado para el Martes")

            elif martes1 == "":
                martes1 = paciente
                print("Turno reservado. Martes - Turno 1")

            elif martes2 == "":
                martes2 = paciente
                print("Turno reservado. Martes - Turno 2")

            elif martes3 == "":
                martes3 = paciente
                print("Turno resrvado. Martes - Turno 3")

            else:
                print("No hay turnos disponibles para Martes")

    # Cancelar:
    elif opcion == "2":

        # Elegir día.

        elegir_dia = input("Seleccione un dia (1 = LUNES / 2 = MARTES): ")
        while not elegir_dia.isdigit() or elegir_dia not in ("1", "2"):
            print("Error: debe elegir opcion 1 o 2")
            elegir_dia = input("Seleccione un dia (1 = LUNES / 2 = MARTES): ")

        # Pedir nombre del paciente (solo letras).

        paciente = input("Nombre del paciente: ")
        while not paciente.isalpha():
            print("Error: debe contener letras")
            paciente = input("Nombre del paciente: ")

        encontrado = False

        # Si existe, cancelar y dejar el espacio vacío ("").
        
        if elegir_dia == "1":

            if paciente == lunes1:
                lunes1 = ""
                encontrado = True

            elif paciente == lunes2:
                lunes2 = ""
                encontrado = True

            elif paciente == lunes3:
                lunes3 = ""
                encontrado = True

            elif paciente == lunes4:
                lunes4 = ""
                encontrado = True

        else:

            if paciente == martes1:
                martes1 = ""
                encontrado = True

            elif paciente == martes2:
                martes2 = ""
                encontrado = True

            elif paciente == martes3:
                martes3 = ""
                encontrado = True

        if encontrado:
            print("Turno cancelado")
        else:
            print("No se ha encontrado un turno reservado para ese paciente")

    # Ver agenda del día:
    elif opcion == "3":

        elegir_dia = input("Seleccione el dia que desea ver la agenda (1 = LUNES / 2 = MARTES): ")
        while not elegir_dia.isdigit() or elegir_dia not in ("1", "2"):
            print("Error: eliga la opcion 1 o 2")
            elegir_dia = input("Seleccione el dia que desea ver la agenda (1 = LUNES / 2 = MARTES): ")

        print()
        # Mostrar los turnos del día en orden (Turno 1..N), indicando “(libre)” si está vacío.
        if elegir_dia == "1":

            print("AGENDA DIA LUNES")

            if lunes1 == "":
                print("Lunes - Turno 1: (libre)")
            else:
                print(f"Lunes - Turno 1: {lunes1}")

            if lunes2 == "":
                print("Lunes - Turno 2: (libre)")
            else:
                print(f"Lunes - Turno 2: {lunes2}")

            if lunes3 == "":
                print("Lunes - Turno 3: (libre)")
            else:
                print(f"Lunes - Turno 3: {lunes3}")

            if lunes4 == "":
                print("Lunes - Turno 4: (libre)")
            else:
                print(f"Lunes - Turno 4: {paciente}")

        else:

            print("AGENDA DIA MARTES")

            if martes1 == "":
                print("Martes - Turno 1: (libre)")
            else:
                print(f"Martes - Turno 1: {martes1}")

            if martes2 == "":
                print("Martes - Turno 2: (libre)")
            else:
                print(f"Martes - Turno 2: {martes2}")

            if martes3 == "":
                print("Martes - Turno 3: (libre)")
            else:
                print(f"Martes - Turno 3: {martes3}")

    # Resumen general:
    elif opcion == "4":

        # Turnos ocupados y disponibles por día.
        dias_ocupados_lunes = 0
        dias_ocupados_martes = 0

        if lunes1 != "":
            dias_ocupados_lunes += 1

        if lunes2 != "":
            dias_ocupados_lunes += 1

        if lunes3 != "":
            dias_ocupados_lunes += 1

        if lunes4 != "":
            dias_ocupados_lunes += 1

        if martes1 != "":
            dias_ocupados_martes += 1

        if martes2 != "":
            dias_ocupados_martes += 1

        if martes3 != "":
            dias_ocupados_martes += 1

        dias_disponibles_lunes = 4 - dias_ocupados_lunes
        dias_disponibles_martes = 3 - dias_ocupados_martes

        print()
        print("RESUMEN GENERAL")
        print()
        print(f"Dias ocupados Lunes: {dias_ocupados_lunes} - Disponibles Lunes: {dias_disponibles_lunes}") 
        print(f"Dias ocupados Martes: {dias_ocupados_martes} - Disponibles Martes: {dias_disponibles_martes}")

        # Día con más turnos (o empate).
        if dias_ocupados_lunes > dias_ocupados_martes:
            print("Dia con mas turnos: LUNES")
        elif dias_ocupados_martes > dias_ocupados_lunes:
            print("Dias con mas turnos: MARTES")
        else:
            print("Dias con mas turnos: EMPATE")

# Cerrar sistema
print()
print("Saliendo del menu...")
print()

#===========================================================================================================

# Ejercicio 4 — “Escape Room: La Bóveda”
# Sos un agente que intenta abrir una bóveda con 3 cerraduras. Tenés energía y tiempo limitados.

print("=" * 30)
print(" " * 3, "ESCAPE ROOM: LA BOVEDA")
print("=" * 30)

# Variables iniciales:
energia = 100
tiempo = 12
cerraduras_abiertas = 0
alarma = False
codigo_parcial = ""
forzadas_seguidas = 0

# • Pedir nombre del agente y validar con .isalpha() en un while.

print()
agente = input("Nombre de agente: ")

while not agente.isalpha():
    print("Error: debe contener letras")
    agente = input("Nombre del agente: ")

print()
print(f"{agente}, tu objetivo es abrir las 3 cerraduras sin activar la alarma")
print()



while energia > 0 and tiempo > 0 and cerraduras_abiertas < 3 and not alarma:

    print("Aqui estan tus recursos:")
    print(f"Energia = {energia}")
    print(f"Tiempo = {tiempo}")
    print(f"Cerraduras abiertas = {cerraduras_abiertas}")
    print(f"Alarma = {alarma}")
    print(f"Codigo Parcial = {codigo_parcial}")
    print()

    print("""Tus Opciones:
1. Forzar cerradura (costo: -20 energia, -2 tiempo)
2. Hackear panel (costo: -10 energia, -3 tiempo)
3. Descansar (costo: +15 energia (maximo = 100), -1 tiempo, si alarma = ON: -10 energia extra)""")
    print()

    opcion = input("Selecciona una opcion: ")

    # Validar opciones del menú y cualquier número pedido con .isdigit() en un while.
    while not opcion.isdigit() or opcion not in ("1", "2", "3"):
        print("Error: opcion invalida")
        opcion = input("Selecciona una opcion: ")

    # 1. Forzar cerradura (costo: -20 energía, -2 tiempo)

    if opcion == "1":

        forzadas_seguidas += 1
        energia -= 20
        tiempo -= 2

        print()
        print("Forzando cerradura...")
        print("Energia = -20 y Tiempo = -2")
        print()


        # Regla anti-spam: si es la 3ra vez seguida forzando, se activa alarma y no abre.
        if forzadas_seguidas == 3:
            print()
            print("¡La cerradura se trabo!")
            print("Alarma activada!!!")
            alarma = True

        # Si la energía está por debajo de 40, hay “riesgo de alarma”
        else:

            if energia < 40:
                print()
                print("Energia baja, hay riesgo de alarma")

            # Pedir un número 1-3 (validado). 
                numero = input("Elige un numero del 1 al 3: ")
                while not numero.isdigit() or numero not in ("1", "2", "3"):
                    print("Error: ingresa alguno de los numeros validos (1,2,3)")
                    numero = input("Elige un numero del 1 al 3: ")

                # Si elige 3 → alarma=True.
                if numero == "3":

                    alarma = True
                    print("Has activado la alarma!")

                # Si no hay alarma, abre 1 cerradura.
                else:

                    cerraduras_abiertas += 1
                    print("Perfecto, has abierto una cerradura exitosamente")

    # 2. Hackear panel (costo: -10 energía, -3 tiempo)
    elif opcion == "2":

        forzadas_seguidas = 0
        energia -= 10
        tiempo -= 3

        print()
        print("Hackeo iniciado...")

        # Debe usar un for de 4 pasos mostrando progreso.
        for i in range(4):

            # En cada paso sumar una letra al codigo_parcial (por ejemplo “A”).
            codigo_parcial += "A"
            print(f"Paso {i+1} - codigo {codigo_parcial}")

            # Si len(codigo_parcial) >= 8, se abre automáticamente 1 cerradura si todavía faltan.
            if len(codigo_parcial) >= 8 and cerraduras_abiertas < 3:

                cerraduras_abiertas += 1
                print()
                print("Perfecto, has abierto una cerradura exitosamente")

            else:

                print()
                print("El hackeo continua...")
                print("Codigo actual", codigo_parcial)

    # 3. Descansar (costo: +15 energía (máx 100), -1 tiempo)
    elif opcion == "3":

        forzadas_seguidas = 0

        energia += 15

        if energia > 100:
            energia = 100

        tiempo -= 1

        print()
        print("Descansando...")
        print("Has recuperado +15 de energia y has perdido -1 de tiempo")
        print()

        # Si alarma ON: -10 energía extra
        if alarma:

            energia -= 10
            print("La alarma esta activa, energia EXTRA -10")

    # Si alarma == True y tiempo <= 3 y todavía no se abrió la bóveda, el sistema se bloquea y se pierde.
    if alarma and tiempo <= 3 and cerraduras_abiertas < 3:

        print()
        print("Sistema de la Boveda bloqueado")
        print("DERROTA")
        break

# Condiciones de fin
print("=" * 20)
print(" " * 2, "RESULTADO FINAL")
print("=" * 20)

print()

# • Si cerraduras_abiertas == 3 → VICTORIA
if cerraduras_abiertas == 3:

    print("¡¡VICTORIA!!")
    print("Las 3 cerraduras se han abierto")
    print("Has abierto la Boveda, felicitaciones!")

# • Si energia <= 0 o tiempo <= 0 → DERROTA
elif energia <= 0 or tiempo <= 0:

    print("!DERROTA¡")
    print("Se te han acabado los recursos")
    print("La Boveda se ha bloqueado")

# • Si se bloquea por alarma → DERROTA (bloqueo)
elif alarma:

    print("!DERROTA¡")
    print("Boveda bloqueada por activacion de la alarma")

print()

#===========================================================================================================

# Ejercicio 5 — “Escape Room:"La Arena del Gladiador"

print("=" * 35)
print("ESCAPE ROOM: LA ARENA DEL GLADIADOR")
print("=" * 35)
print()

# Variables iniciales (sin preguntar al usuario):

vida_del_gladiador = 100
vida_del_enemigo = 100
pociones_de_vida = 3
daño_base = 15 # "Ataque Pesado"
daño_base_del_enemigo = 12
turno_gladiador = True

print(" " * 2, "--- BIENVENIDO A LA ARENA ---")

# El programa inicia pidiendo el nombre del Gladiador.
gladiador = input("Ingrese el nombre del Gladiador: ")

# • Validación: El nombre solo puede contener letras. 
while not gladiador.isalpha():
    print("Error: solo se permiten letras")
    gladiador = input("Ingrese el nombre del Gladiador: ")
    print()


# Ciclo de Combate
# El juego entra en un ciclo que se repite mientras ambos combatientes tengan más de 0 puntos de vida.

opcion = ""
primer_turno = True
while vida_del_gladiador > 0 and vida_del_enemigo > 0:

    if primer_turno:
        print()
        print(" " * 2, "=== INICIO DEL COMBATE ===")
        primer_turno = False
    else:
        print()
        print(" " * 3, "=== NUEVO TURNO ===")

    # Muestra la vida actual de ambos y las pociones restantes
    print()
    print(f"{gladiador} (HP: {vida_del_gladiador}) vs Enemigo (HP: {vida_del_enemigo}) / posiones: {pociones_de_vida}")

    # Luego, ofrece un menú con 3 opciones:
    print("""
    Opciones:

    1. Ataque Pesado
    2. Rafaga veloz
    3. Curar""")
    
    opcion = input("Eliga la opcion a ejecutar: ")
    print()

    # Validación del Menú:
    while not opcion.isdigit() or opcion not in ("1", "2", "3"):
        print("Error: opcion no valida")
        opcion = input("Eliga la opcion a ejecutar:")
        print()

    # Ataque Pesado (Opción 1)
    if opcion == "1":

        # Si la vida del enemigo es menor a 20 puntos, el jugador realiza un "Golpe Crítico"
        if vida_del_enemigo < 20:
            daño_critico = daño_base * 1.5
            vida_del_enemigo = vida_del_enemigo - daño_critico
            print("Golpe Critico!")
            print(f"¡Atacaste al enemigo por {daño_critico} puntos de daño!")

        # Muestra un mensaje: "¡Atacaste al enemigo por X puntos de daño!"
        else:
            vida_del_enemigo = vida_del_enemigo - daño_base
            print(f"¡Atacaste al enemigo por {daño_base} puntos de daño!")

    # Ráfaga Veloz (Opción 2)
    elif opcion == "2":

        # El bucle debe repetirse 3 veces (usando for y range).
        for i in range(3):

            # Resta 5 puntos de daño a la vida del enemigo.
            vida_del_enemigo = vida_del_enemigo - 5

            # Muestra el mensaje: " > Golpe conectado por 5 de daño".
            print("> Golpe conectado por 5 de daño")

    # Curar (Opción 3) 
    elif opcion == "3":

        # Si tienes pociones (> 0): Suma 30 puntos a tu vida y resta 1 poción.
        if pociones_de_vida > 0:
            
            vida_del_gladiador += 30

            if vida_del_gladiador > 100:
                vida_del_gladiador = 100

            pociones_de_vida -= 1

            print("Te has curado por 30 de HP")
            print(f"Vida: {vida_del_gladiador} HP")
            print(f"Pociones restantes: {pociones_de_vida}")

        # Si NO tienes pociones: Muestra "¡No quedan pociones!" y pierdes el turno (el enemigo ataca igual).
        else:
            print("¡No te quedan mas pociones!")
            print("Perdiste el turno, turno del enemigo")

    # Resta el daño base del enemigo (12) a tu vida.
    vida_del_gladiador -= daño_base_del_enemigo

    # Muestra un mensaje: "¡El enemigo te atacó por 12 puntos de daño!"
    print("¡El enemigo te ataco por 12 puntos de daño!")


# Fin del Juego

print()

# Si vida_jugador > 0: Mostrar "¡VICTORIA! [Nombre] ha ganado la batalla.
if vida_del_gladiador > 0:
    print(f"¡VICTORIA! {gladiador} ha ganado la batalla")

# Si vida_jugador <= 0: Mostrar "DERROTA. Has caído en combate."
else:
    print("DERROTA! Has caido en combate")


# Actividad Nro 1 
# Crear un programa que imprima por pantalla el mensaje: “Hola Mundo!”.

print ("Hola Mundo!")

# Actividad Nro 2
# Crear un programa que pida al usuario su nombre e imprima por pantalla un saludo usando
# el nombre ingresado. Por ejemplo: si el usuario ingresa “Marcos”, el programa debe imprimir
# por pantalla “Hola Marcos!”. Consejo: esto será más sencillo si utilizas print(f…) para
# realizar la impresión por pantalla.

nombre = input("Ingrese su nombre por favor:")
print (f"Hola {nombre}!")

# Actividad Nro 3 
# Crear un programa que pida al usuario su nombre, apellido, edad y lugar de residencia e
# imprima por pantalla una oración con los datos ingresados. Por ejemplo: si el usuario ingresa
# “Marcos”, “Pérez”, “30” y “Argentina”, el programa debe imprimir “Soy Marcos Pérez, tengo 30
# años y vivo en Argentina”. Consejo: esto será más sencillo si utilizas print(f…) para realizar
# la impresión por pantalla

nombre = input("Ingrese por favor su nombre: ")
apellido = input("Ahora ingrese su apellido: ")
edad = input("Introduzca su edad: ")
residencia = input("Ahora ingrese su pais de residencia: ")
print(f"Soy {nombre} {apellido}, tengo {edad} años y vivo en {residencia}.")

# Actividad Nro 4
# Crear un programa que pida al usuario el radio de un círculo e imprima por pantalla su área y su perímetro.

radio = int(input("Ingrese el valor del radio de un circulo: "))

pi = 3.14
area = pi * radio * radio
perimetro = 2 * pi * radio 

print("El area del circulo es de: ", area)
print("Y el perimetro es: ", perimetro)

# Actividad Nro 5
# Crear un programa que pida al usuario una cantidad de segundos e imprima por pantalla a
# cuántas horas equivale.

segundos = int(input("Ingrese una cantidad cualquiera de segundos: "))

horas = segundos/3600

print("La cantidad de segundos ingresados, equivalen a ", horas ,"horas.")

# Actividad Nro 6
# Crear un programa que pida al usuario un número e imprima por pantalla la tabla de
# multiplicar de dicho número.

numero = int(input("Ingrese un numero aleatorio: "))
print(f"Tabla de multiplicar de: {numero}")

for i in range (1, 11):
    print(f"{numero} x {i} = {numero * i}")

# Actividad Nro 7
# Crear un programa que pida al usuario dos números enteros distintos del 0 y muestre por
# pantalla el resultado de sumarlos, dividirlos, multiplicarlos y restarlos.

numero1 = int(input("Ingrese un numero aleatorio distinto de 0: "))
numero2 = int(input("Ahora ingrese un segundo numero aleatorio: "))

suma = numero1 + numero2
division = numero1 // numero2
multiplicacion = numero1 * numero2
resta = numero1 - numero2

print(f"""
El resultado de la suma entre numero 1 y numero 2 es de: {suma}
El resultado de la divison entre numero 1 y numero 2 es de: {division}
El resultado de la multiplicacion entre numero 1 y numero 2 es de: {multiplicacion}
El resultado de la resta entre numero 1 y numero 2 es de: {resta} """)

# Actividad Nro 8 
# Crear un programa que pida al usuario su altura y su peso e imprima por pantalla su índice
# de masa corporal. Tener en cuenta que el índice de masa corporal se calcula del siguiente modo:
# IMC = peso en kg / (altura en m)2

altura = float(input("Por favor, ingrese su altura: "))
peso_Corp = float(input("Ingrese ahora su peso: "))
imc = peso_Corp / (altura**2)

print(f"Su indice de masa corporal es de: {imc} ")

# Actividad Nro 9
# Crear un programa que pida al usuario una temperatura en grados Celsius e imprima por
# pantalla su equivalente en grados Fahrenheit. Tener en cuenta la siguiente equivalencia:
# 𝑇𝑒𝑚𝑝𝑒𝑟𝑎𝑡𝑢𝑟𝑎 𝑒𝑛 𝐹𝑎ℎ𝑟𝑒𝑛ℎ𝑒𝑖𝑡 = 9/5 * temperatura en Celcius + 32

grados_Celsius = int(input("Ingrese una temperatura en grados Celsius: "))
temp_Fahrenheit = 9/5 * grados_Celsius + 32

print(f"El equivalente de {grados_Celsius}° grados Celsius a grados Fahrenheit es de: {temp_Fahrenheit}°F ")

# Actividad Nro 10
# Crear un programa que pida al usuario 3 números e imprima por pantalla el promedio de
# dichos números.

numero1 = int(input("Ingrese un primer numero aleatorio: "))
numero2 = int(input("Ingrese un segundo numero aleatorio: "))
numero3 = int(input("Ahora ingrese un tercer numero aleatorio: "))
promedio = (numero1 + numero2 + numero3) / 3

print(f"El promedio de los numeros {numero1, numero2, numero3} es de: {promedio}")
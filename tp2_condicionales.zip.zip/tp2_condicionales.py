# Actividad Nro 1
# Escribir un programa que solicite la edad del usuario. Si el usuario es mayor de 18 años,
# deberá mostrar un mensaje en pantalla que diga “Es mayor de edad”.

edad_usuario = int(input("Por favor ingrese su edad: "))

if edad_usuario > 18: 
    print("Usted es mayor de edad")
else:
    print("Usted no es mayor de edad")

print()
# Actividad Nro 2
# Escribir un programa que solicite su nota al usuario. Si la nota es mayor o igual a 6, deberá
# mostrar por pantalla un mensaje que diga “Aprobado”; en caso contrario deberá mostrar el
# mensaje “Desaprobado”.

nota = int(input("Ingrese su nota: "))

if nota >= 6:
    print("Aprobado")
else: 
    print("Desaprobado")

print()
# Actividad Nro 3
# Escribir un programa que permita ingresar solo números pares. Si el usuario ingresa un
# número par, imprimir por en pantalla el mensaje "Ha ingresado un número par"; en caso
# contrario, imprimir por pantalla "Por favor, ingrese un número par". Nota: investigar el uso del
# operador de módulo (%) en Python para evaluar si un número es par o impar.

numero = int(input("Ingrese un numero: "))

if numero % 2 == 0: 
    print("Ha ingresado un numero par")
else: 
    print("Por favor, ingrese un numero par")

print()
# Actividad Nro 4
# Escribir un programa que solicite al usuario su edad e imprima por pantalla a cuál de las
# siguientes categorías pertenece:
# ● Niño/a: menor de 12 años.
# ● Adolescente: mayor o igual que 12 años y menor que 18 años.
# ● Adulto/a joven: mayor o igual que 18 años y menor que 30 años.
# ● Adulto/a: mayor o igual que 30 años.

edad = int(input("Ingrese su edad: "))

if edad < 12:
    print("Estas dentro de la categoria de Niños")
elif edad < 18:
    print("Perteneces a la categoria de Adolescente")
elif edad < 30:
    print("Perteneces a la categoria de Adulto joven")
elif edad >= 30: 
    print("Perteneces a la categoria de Adultos")

print()
# Actividad Nro 5
# Escribir un programa que permita introducir contraseñas de entre 8 y 14 caracteres
# (incluyendo 8 y 14). Si el usuario ingresa una contraseña de longitud adecuada, imprimir por en
# pantalla el mensaje "Ha ingresado una contraseña correcta"; en caso contrario, imprimir por
# pantalla "Por favor, ingrese una contraseña de entre 8 y 14 caracteres". Nota: investigue el uso
# de la función len() en Python para evaluar la cantidad de elementos que tiene un iterable tal
# como una lista o un string

contraseña = input("Ingrese una contraseña: ")

if 8 <= len(contraseña) <= 14:
    print("Ha ingresado una contraseña correcta")
else:
    print("Por favor, ingrese una contaraseña de entre 8 y 14 caracteres")

print()
# Actividad Nro 6
# Escribir un programa que solicite al usuario el consumo mensual de energía eléctrica en
# kilovatios (kWh) e indique la categoría del consumo según el siguiente criterio:
# • Menor que 150 kWh: “Consumo bajo”.
# • Entre 150 y 300 kWh (inclusive): “Consumo medio”.
# • Mayor que 300 kWh: “Consumo alto”.
# Además, si el consumo supera los 500 kWh, mostrar un mensaje adicional que diga:
# “Considere medidas de ahorro energético”.
# El programa debe imprimir por pantalla la categoría correspondiente.

print("CONSUMO MENSUAL DE ENERGIA ELECTRICA")

consumo = int(input("Ingrese la cantidad de kilovatios (kwh) consumidos en el mes: "))

if consumo < 150: 
    print("Consumo bajo")
elif consumo >= 150 and consumo <= 300:
    print("Consumo medio")
elif consumo > 300:
    print("Consumo alto")
elif consumo > 500:
    print("Considere medidas de ahorro energetico")
else:
    print("No se puede calcular el consumo con valores negativos")

print()
# Actividad Nro 7 
# Escribir un programa que solicite una frase o palabra al usuario. Si el string ingresado
# termina con vocal, añadir un signo de exclamación al final e imprimir el string resultante por
# pantalla; en caso contrario, dejar el string tal cual lo ingresó el usuario e imprimirlo por pantalla.

palabra = input("Ingrese una palabra aleatoria: ")
ultimo = palabra[-1].lower()

if ultimo in "aeiou":
     palabra = palabra + "!"

print(palabra)

print()
# Actividad Nro 8
# Escribir un programa que solicite al usuario que ingrese su nombre y el número 1, 2 o 3
# dependiendo de la opción que desee:
# 1. Si quiere su nombre en mayúsculas. Por ejemplo: PEDRO.
# 2. Si quiere su nombre en minúsculas. Por ejemplo: pedro.
# 3. Si quiere su nombre con la primera letra mayúscula. Por ejemplo: Pedro.
# El programa debe transformar el nombre ingresado de acuerdo a la opción seleccionada por el
# usuario e imprimir el resultado por pantalla. Nota: investigue uso de las funciones upper(),
# lower() y title() de Python para convertir entre mayúsculas y minúsculas.

nombre = input("Ingrese su nombre por favor: ")

print("Para obtener su nombre en mayusculas ingrese el numero 1" \
" sino ingresa el numero 2 para obtener su nombre en minusculas o el numero 3 para obtener su nombre" \
" con la primera letra en mayusculas y el resto en minusculas")

opcion = input("Ingrese el numero que desee: ")

if opcion == "1": 
     print(nombre.upper())
elif opcion == "2":
     print(nombre.lower())
elif opcion == "3": 
     print(nombre.title())
else: 
     print("Opcion invalida, ingrese las opciones 1 , 2 o 3")

print()
# Actividad Nro 9
# Escribir un programa que pida al usuario la magnitud de un terremoto, clasifique la
# magnitud en una de las siguientes categorías según la escala de Richter e imprima el resultado
# por pantalla:
# ● Menor que 3: "Muy leve" (imperceptible).
# ● Mayor o igual que 3 y menor que 4: "Leve" (ligeramente perceptible).
# ● Mayor o igual que 4 y menor que 5: "Moderado" (sentido por personas, pero generalmente no causa daños).
# ● Mayor o igual que 5 y menor que 6: "Fuerte" (puede causar daños en estructuras débiles).
# ● Mayor o igual que 6 y menor que 7: "Muy Fuerte" (puede causar daños significativos).
# ● Mayor o igual que 7: "Extremo" (puede causar graves daños a gran escala).

magnitud = int(input("Ingrese un valor de un terremoto para saber su magnitud en escala de Richter: "))

if magnitud < 3:
     print("Muy leve (imperceptible)")
elif magnitud < 4:
     print("Leve (ligeramente perceptible)") 
elif magnitud < 5:
     print("Moderado (sentido por personas, pero generalmente no causan daños)")
elif magnitud < 6:
     print("Fuerte (puede causar daños en estructuras debiles)")
elif magnitud < 7:
     print("Muy fuerte (puede causar daños significativos)")
elif magnitud >= 7:
     print("Extremo (puede causar graves daños a gran escala)")

print()
# Actividad Nro 10
# Escribir un programa que pregunte al usuario en cuál hemisferio se encuentra (N/S), qué mes
# del año es y qué día es. El programa deberá utilizar esa información para imprimir por pantalla
# si el usuario se encuentra en otoño, invierno, primavera o verano.

hemisferio = input("Indique en que hemisferio se encuentra actualmente (N/S): ")
mes = input("Indique el mes del año actual: ")
dia = int(input("Por ultimo, indique que dia es: "))

match hemisferio:
    case "N":
        if (mes == "diciembre" and dia >= 21) or (mes == "enero") or (mes == "febrero") or (mes == "marzo" and dia <= 20):
            print("En tu ciudad actual estan en invierno")
        elif (mes == "marzo" and dia >= 21) or (mes == "abril") or (mes == "mayo") or (mes == "junio" and dia <= 20):
            print("En tu ciudad actual estan en primavera")
        elif (mes == "junio" and dia >= 21) or (mes == "julio") or (mes == "agosto") or (mes == "septiembre" and dia <= 20):
            print("En tu ciudad actual estan en verano")
        elif (mes == "septiembre" and dia >= 21) or (mes == "octubre") or (mes == "noviembre") or (mes == "diciembre" and dia <=20):
            print("En tu ciudad actual estan en otoño")

    case "S":
        if (mes == "diciembre" and dia >= 21) or (mes == "enero") or (mes == "febrero") or (mes == "marzo" and dia <= 20):
            print("En tu ciudad actual estan en Verano")
        elif (mes == "marzo" and dia >= 21) or (mes == "abril") or (mes == "mayo") or (mes == "junio" and dia <= 20):
            print("En tu ciudad actual estan en otoño")
        elif (mes == "junio" and dia >= 21) or (mes == "julio") or (mes == "agosto") or (mes == "septiembre" and dia <= 20):
            print("En tu ciudad actual estan en invierno")
        elif (mes == "septiembre" and dia >= 21) or (mes == "octubre") or (mes == "noviembre") or (mes == "diciembre" and dia <= 20):
            print("En tu ciudad actual estan en primavera")